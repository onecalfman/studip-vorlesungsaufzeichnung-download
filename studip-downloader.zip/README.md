# StudIP Vorlesungsaufzeichnungen Download Button

Einfaches Browser-Addon (Chrome, Firefox), das auf StudIP für jede auzgezeichnete Vorlesung einen Downloadbutton einfügt.

### TODO:
Download über chrome/browser download API, damit der Name der Heruntergeladenen Datei der Vorlesungsname ist und nicht der Interne Name auf StudIP/opencast.
